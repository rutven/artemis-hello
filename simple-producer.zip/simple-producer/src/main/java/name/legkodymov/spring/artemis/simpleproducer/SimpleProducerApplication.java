package name.legkodymov.spring.artemis.simpleproducer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleProducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleProducerApplication.class, args);
	}

}
