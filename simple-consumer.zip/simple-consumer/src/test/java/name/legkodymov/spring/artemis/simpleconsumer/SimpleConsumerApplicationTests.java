package name.legkodymov.spring.artemis.simpleconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
